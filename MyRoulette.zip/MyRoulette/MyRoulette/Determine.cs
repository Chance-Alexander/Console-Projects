﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace MyRoulette
{
    class Determine
    {
        public static void Ask(Player player, Results results)
        {
            int play = 0;
            player.Play = "";
            WriteLine($"The initial 10 turns are complete!\n Your final wallet is ${player.Cash}\n\n");
            WriteLine("Would you like to keep playing?\n");
            WriteLine("1:>> Yes\n2:>> No");
            while (!int.TryParse(player.Play, out play))
            {
                player.Play = ReadLine();
            }
            if (play > 2 || play < 1)
            {
                Ask(player, results);
            }
            switch (play)
            {
                case 1:
                    while (player.Running == true)
                    {
                        GameProcess.Game(player, results);
                    }
                    break;
                case 2:
                    Environment.Exit(0);
                    break;
            }
        }
        public static void Bet(Player player)
        {
            player.Bet = "";
            int bet;
            while (!int.TryParse(player.Bet, out bet))
            {
                player.Bet = ReadLine();
                //betoption = Convert.ToInt32(player.betoption);
            }
            WriteLine($"Your bet is {player.Bet}\n");
            if (bet > player.Cash)
            {
                WriteLine($"You do not have enough in your wallet for that bet.");
                ReadLine();
                Bet(player);
            }
            player.Betii = bet;
            player.Cash -= player.Betii;
        }
        public static void FindNumber(Results results, Player player)
        {
            player.BetChoice = "";
            int betchoice;
            WriteLine("Enter the Number you're betting on :");
            while (!int.TryParse(player.BetChoice, out betchoice))
            {
                player.BetChoice = ReadLine();
            }
            if (betchoice >= 36 || betchoice <= -1)
            {
                WriteLine(">>Invalid Selection<<");
                FindNumber(results, player);
            }
            if (betchoice == results.WinNum[results.Index])
            {
                player.Win = true;

            }
        }
        public static void FindCorner(Results results, Player player)
        {
            int winner = results.WinNum[results.Index];
            string cornernum = "";
            int cornerbet;
            //Create a system to determine if a corner bet was placed...
            WriteLine("The Corners to select from are :\n1,2,4,5\n2,3,5,6\n4,5,7,8,\n5,6,8,9,\n7,8,10,11,\n8,9,11,12,\n10,11,13,14," +
                "\n11,12,14,15,\n13,14,16,17,\n14,15,17,18,\n16,17,19,20,\n17,18,20,21,\n19,20,22,23,\n20,21,23,24,\n22,23,25,26,\n23,24,26,27," +
                "\n25, 26,28,29,\n26,27,29,30,\n28,29,31,32,\n29,30,32,33,\n31,32,34,35,\n32,33,35,36");
            WriteLine("Type in the LOWEST number of the corner you are betting on :");
            Write(":>>");
            while (!int.TryParse(cornernum, out cornerbet))
            {
                cornernum = ReadLine();
            }
            if (cornerbet < 1 || cornerbet > 36)
            {
                Clear();
                Write("NOT A VALID SELECTION");
                FindCorner(results, player);
            }
            if (cornerbet==winner||cornerbet+1==winner||cornerbet+3==winner||cornerbet+4==winner)
            {
                player.Win = true;
            }
        }
        public static void FindStreet(Results results, Player player)
        {
            int betoption;
            player.BetOption = "";
            WriteLine("Enter the Street you're betting on :\n");
            WriteLine("1: >> 1/2/3\n");
            WriteLine("2: >> 4/5/6\n");
            WriteLine("3: >> 7/8/9\n");
            WriteLine("4: >> 10/11/12\n");
            WriteLine("5: >> 13/14/15\n");
            WriteLine("6: >> 16/17/18\n");
            WriteLine("7: >> 19/20/21\n");
            WriteLine("8: >> 22/23/24\n");
            WriteLine("9: >> 25/26/27\n");
            WriteLine("10: >> 28/29/30\n");
            WriteLine("11: >> 31/32/33\n");
            WriteLine("12: >> 34/35/36\n");
            Write(">>");
            while (!int.TryParse(player.BetOption, out betoption))
            {
                player.BetOption = ReadLine();
                //betoption = Convert.ToInt32(player.betoption);
            }
            if (betoption >= 13 || betoption <= 0)
            {
                WriteLine(">>Invalid Selection<<");
                FindStreet(results, player);
            }
            switch (betoption)
            {
                case 1:
                    if (results.WinNum[results.Index] == 1 || results.WinNum[results.Index] == 2 || results.WinNum[results.Index] == 3)
                    {
                        player.Win = true;
                    }
                    break;
                case 2:
                    if (results.WinNum[results.Index] == 4 || results.WinNum[results.Index] == 5 || results.WinNum[results.Index] == 6)
                    {
                        player.Win = true;
                    }
                    break;
                case 3:
                    if (results.WinNum[results.Index] == 7 || results.WinNum[results.Index] == 8 || results.WinNum[results.Index] == 9)
                    {
                        player.Win = true;
                    }
                    break;
                case 4:
                    if (results.WinNum[results.Index] == 10 || results.WinNum[results.Index] == 11 || results.WinNum[results.Index] == 12)
                    {
                        player.Win = true;
                    }
                    break;
                case 5:
                    if (results.WinNum[results.Index] == 13 || results.WinNum[results.Index] == 14 || results.WinNum[results.Index] == 15)
                    {
                        player.Win = true;
                    }
                    break;
                case 6:
                    if (results.WinNum[results.Index] == 16 || results.WinNum[results.Index] == 17 || results.WinNum[results.Index] == 18)
                    {
                        player.Win = true;
                    }
                    break;
                case 7:
                    if (results.WinNum[results.Index] == 19 || results.WinNum[results.Index] == 20 || results.WinNum[results.Index] == 21)
                    {
                        player.Win = true;
                    }
                    break;
                case 8:
                    if (results.WinNum[results.Index] == 22 || results.WinNum[results.Index] == 23 || results.WinNum[results.Index] == 24)
                    {
                        player.Win = true;
                    }
                    break;
                case 9:
                    if (results.WinNum[results.Index] == 25 || results.WinNum[results.Index] == 26 || results.WinNum[results.Index] == 27)
                    {
                        player.Win = true;
                    }
                    break;
                case 10:
                    if (results.WinNum[results.Index] == 28 || results.WinNum[results.Index] == 29 || results.WinNum[results.Index] == 30)
                    {
                        player.Win = true;
                    }
                    break;
                case 11:
                    if (results.WinNum[results.Index] == 31 || results.WinNum[results.Index] == 32 || results.WinNum[results.Index] == 33)
                    {
                        player.Win = true;
                    }
                    break;
                case 12:
                    if (results.WinNum[results.Index] == 34 || results.WinNum[results.Index] == 35 || results.WinNum[results.Index] == 36)
                    {
                        player.Win = true;
                    }
                    break;
            }

        }
        public static void FindDozen(Results results, Player player)
        {
            int betoption;
            player.BetOption = "";
            WriteLine("Enter the Dozens you're betting on :\n");
            WriteLine("1: >> 1 - 12\n");
            WriteLine("2: >> 12 - 24\n");
            WriteLine("3: >> 24 - 36");
            while (!int.TryParse(player.BetOption, out betoption))
            {
                player.BetOption = ReadLine();
                //betoption = Convert.ToInt32(player.betoption);
            }
            if (betoption >= 4 || betoption <= 0)
            {
                WriteLine(">>Invalid Selection<<");
                FindDozen(results, player);
            }
            switch (betoption)
            {
                case 1:
                    if (results.WinNum[results.Index] >= 1 && results.WinNum[results.Index] <= 12)
                    {
                        player.Win = true;
                    }
                    break;
                case 2:
                    if (results.WinNum[results.Index] >= 13 && results.WinNum[results.Index] <= 24)
                    {
                        player.Win = true;
                    }
                    break;
                case 3:
                    if (results.WinNum[results.Index] >= 25 && results.WinNum[results.Index] <= 36)
                    {
                        player.Win = true;
                    }
                    break;
            }
        }
        public static void FindColumn(Results results, Player player)
        {
            int winnum = results.WinNum[results.Index];
            int betoption;
            player.BetOption = "";
            WriteLine("Enter the Column you're betting on :\n");
            WriteLine("1: >> 1st Column\n");
            WriteLine("2: >> 2nd Column\n");
            WriteLine("3: >> 3rd Column\n");
            while (!int.TryParse(player.BetOption, out betoption))
            {
                player.BetOption = ReadLine();
                //betoption = Convert.ToInt32(player.betoption);
            }
            if (betoption >= 4 || betoption <= 0)
            {
                WriteLine(">>Invalid Selection<<");
                FindColumn(results, player);
            }
            switch (betoption)
            {
                case 1:
                    if (winnum == 1 || winnum == 4 || winnum == 7 || winnum == 10 || winnum == 13 || winnum == 16 || winnum == 19 || winnum == 22 || winnum == 25 || winnum == 28 || winnum == 31 || winnum == 34)
                    {
                        player.Win = true;
                    }
                    break;
                case 2:
                    if (winnum == 2 || winnum == 5 || winnum == 8 || winnum == 11 || winnum == 14 || winnum == 17 || winnum == 20 || winnum == 23 || winnum == 26 || winnum == 29 || winnum == 32 || winnum == 35)
                    {
                        player.Win = true;
                    }
                    break;
                case 3:
                    if (winnum == 3 || winnum == 6 || winnum == 9 || winnum == 12 || winnum == 15 || winnum == 18 || winnum == 21 || winnum == 24 || winnum == 27 || winnum == 30 || winnum == 33 || winnum == 36)
                    {
                        player.Win = true;
                    }
                    break;
            }
        }
        public static void FindDub(Results results, Player player)
        {
            int winnum = results.WinNum[results.Index];
            int betoption;
            player.BetOption = "";
            WriteLine("Enter the Double Rows you're betting on :\n");
            WriteLine("1:>> 1/2/3/4/5/6\n");
            WriteLine("2:>> 7/8/9/10/11/12\n");
            WriteLine("3:>> 13/14/15/16/17/18\n");
            WriteLine("4:>> 19/20/21/22/23/24\n");
            WriteLine("5:>> 25/26/27/28/29/30\n");
            WriteLine("6:>> 31/32/33/34/35/36\n");
            while (!int.TryParse(player.BetOption, out betoption))
            {
                player.BetOption = ReadLine();
            }
            if (betoption > 6 || betoption < 1)
            {
                FindDub(results, player);
            }
            switch (betoption)
            {
                case 1:
                    if (winnum == 1 || winnum == 2 || winnum == 3 || winnum == 4 || winnum == 5 || winnum == 6)
                    {
                        player.Win = true;
                    }
                    break;
                case 2:
                    if (winnum == 7 || winnum == 8 || winnum == 9 || winnum == 10 || winnum == 11 || winnum == 12)
                    {
                        player.Win = true;
                    }
                    break;
                case 3:
                    if (winnum == 13 || winnum == 14 || winnum == 15 || winnum == 16 || winnum == 17 || winnum == 18)
                    {
                        player.Win = true;
                    }
                    break;
                case 4:
                    if (winnum == 19 || winnum == 20 || winnum == 21 || winnum == 22 || winnum == 23 || winnum == 24)
                    {
                        player.Win = true;
                    }
                    break;
                case 5:
                    if (winnum == 25 || winnum == 26 || winnum == 27 || winnum == 28 || winnum == 29 || winnum == 30)
                    {
                        player.Win = true;
                    }
                    break;
                case 6:
                    if (winnum == 31 || winnum == 32 || winnum == 33 || winnum == 34 || winnum == 35 || winnum == 36)
                    {
                        player.Win = true;
                    }
                    break;
            }
        }
        public static void FindHL(Results results, Player player)
        {
            int betchoice;
            player.BetChoice = "";
            WriteLine("Enter the Range you're betting on :\n");
            WriteLine("1: >> Low\n");
            WriteLine("2: >> High");
            while (!int.TryParse(player.BetChoice, out betchoice))
            {
                player.BetChoice = ReadLine();
            }
            if (betchoice > 2 || betchoice < 1)
            {
                WriteLine("\n>>Invalid Input<<\n");
                Write("Enter Valid choice : >>");
                FindHL(results, player);
            }
            switch (betchoice)
            {
                case 1:
                    if (betchoice == 2 && results.WinNum[results.Index] >= 19)
                    {
                        player.Win = true;
                    }
                    break;
                case 2:
                    if (betchoice == 1 && results.WinNum[results.Index] <= 18)
                    {
                        player.Win = true;
                    }
                    break;
            }
        }
        public static void FindSplit(Results results, Player player)
        {
            int betchoice;
            player.BetChoice = "";
            player.BetOption = "";
            int betoption;
            WriteLine("Enter the Lowest number of the Split you're betting on (1 - 33, as 36 is the highest number for a split):\n");
            Write(">>");
            while (!int.TryParse(player.BetChoice, out betchoice))
            {
                player.BetChoice = ReadLine();
            }
            if (betchoice < 1 || betchoice > 33)
            {
                Clear();
                WriteLine("\n>>INVALID SELECTION, RE-ENTER INPUT A NUMBER 1 - 33!<<\n");
                FindSplit(results, player);
            }
            Clear();
            WriteLine("Do you want to bet Horizontally or Vertically?\n\nNOTE: All bets placed in the last column (3/6/9/etc.) will be treated as Vertical bets NO MATTER YOUR CHOICE\n\n");
            WriteLine("1:>> Horizontally\n2:>> Vertically");
            while (!int.TryParse(player.BetOption, out betoption))
            {
                player.BetOption = ReadLine();
            }
            if (betoption > 2 || betoption < 1)
            {
                Clear();
                WriteLine("\n>>INVALID SELECTION, RE-ENTER INPUT!<<\n");
                FindSplit(results, player);
            }
            if (betchoice != 3 || betchoice != 6 || betchoice != 9 || betchoice != 12 || betchoice != 15 || betchoice != 18 || betchoice != 21 || betchoice != 24 || betchoice != 27 || betchoice != 30 || betchoice != 33 || betchoice != 36)
            {
                player.ExtraInt = betchoice;
                player.ExtraIntii = betoption;
                FindSplitii(results, player);
            }
            else if (betchoice + 3 == results.WinNum[results.Index]||betchoice==results.WinNum[results.Index])
            {
                player.Win = true;
            }
        }
        public static void FindSplitii(Results results, Player player)
        {
            int betchoice = player.ExtraInt; //the number on the table chosen by user
            int betoption = player.ExtraIntii; //horizontal or vertical chosen by user... 1 is horiz...2 is vert...
            if (betoption == 1)
            {
                if (betchoice + 1 == results.WinNum[results.Index] || betchoice == results.WinNum[results.Index])
                { player.Win = true; }
            }
            else if (betoption == 2)
            {
                if (betchoice + 3 == results.WinNum[results.Index] || betchoice == results.WinNum[results.Index])
                { player.Win = true; }
            }
            else { player.Win = false; }
        }
        public static void EvenOdd(Results results, Player player)
        {
            player.BetChoice = "";
            int betchoice;
            WriteLine("Enter the Option you're betting on :\n");
            WriteLine("1. >> Evens\n");
            WriteLine("2. >> Odds");
            while (!int.TryParse(player.BetChoice, out betchoice))
            {
                player.BetChoice = ReadLine();
            }
            if (betchoice > 2 || betchoice < 1)
            {
                WriteLine("\n>>Invalid Choice<<\nPlease select a valid choice.");
                EvenOdd(results, player);
            }
            if (results.WinNum[results.Index] % 2 != 0 && betchoice == 2)
            {
                WriteLine($"You have won the bet!  +${player.Betii * 2}!");
                player.Cash += (player.Betii * 2);
            }
            else if (results.WinNum[results.Index] % 2 == 0 && betchoice == 1)
            {
                WriteLine($"You have won the bet!  +${player.Betii * 2}!");
                player.Cash += (player.Betii * 2);
            }
            else { WriteLine("Unfortunately for you, and fortunate for the virtual casino, you have lost."); }
        }
        public static void Color(Results results, Player player)
        {
            player.BetChoice = "";
            int betchoice;
            WriteLine("Enter the Color you're betting on :\n");
            WriteLine("1: >> Red\n");
            WriteLine("2: >> Black");
            while (!int.TryParse(player.BetChoice, out betchoice))
            {
                player.BetChoice = ReadLine();
            }
            if (betchoice > 2 || betchoice < 1)
            {
                Clear();
                WriteLine("\n>>INVALID CHOICE<<\nPlease Enter a Valid choice.");
                Color(results, player);
            }
            if (betchoice == 1 && results.WinColor[results.Index] == "Red")
            {
                WriteLine($"You have won the bet!  +${player.Betii * 2}!");
                player.Cash += (player.Betii * 2);
            }
            else if (betchoice == 2 && results.WinColor[results.Index] == "Black")
            {
                WriteLine($"You have won the bet!  +${player.Betii * 2}!");
                player.Cash += (player.Betii * 2);
            }
            else { WriteLine("Unfortunately for you, and fortunate for the virtual casino, you have lost."); }
        }
    }
}
