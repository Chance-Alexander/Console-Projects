﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace MyRoulette
{
    class GameProcess
    {

        public static void Game(Player player, Results results)
        {
            //instantiated Random and assigned variable for brevity
            Random random = new Random();
            BackgroundColor = ConsoleColor.DarkGreen;
            int index = random.Next(0, 37);
            int winNum = results.WinNum[index];
            string winColor = results.WinColor[index];
            results.Index = index;
            player.Win = false;
            player.ExtraInt = 0;
            player.ExtraIntii = 0;

            //If statement for a bankrupted player, meaning game over

            if (player.Cash <= 0)
            {
                Clear();
                ForegroundColor = ConsoleColor.Yellow;
                WriteLine("You have become bankrupt!");
                ForegroundColor = ConsoleColor.Red;
                WriteLine("GAME OVER!");
                ReadLine();
                Environment.Exit(0); //This exits the application by force
            }
            Clear();

            //Display for the player's wallet and turn count
            ForegroundColor = ConsoleColor.Black;
            WriteLine($"Wallet : ${player.Cash}      Turn : {player.Turn}\n\n");
            string title = @"
 .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------. 
| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |
| |  _______     | || |     ____     | || | _____  _____ | || |   _____      | || |  _________   | || |  _________   | || |  _________   | || |  _________   | |
| | |_   __ \    | || |   .'    `.   | || ||_   _||_   _|| || |  |_   _|     | || | |_   ___  |  | || | |  _   _  |  | || | |  _   _  |  | || | |_   ___  |  | |
| |   | |__) |   | || |  /  .--.  \  | || |  | |    | |  | || |    | |       | || |   | |_  \_|  | || | |_/ | | \_|  | || | |_/ | | \_|  | || |   | |_  \_|  | |
| |   |  __ /    | || |  | |    | |  | || |  | '    ' |  | || |    | |   _   | || |   |  _|  _   | || |     | |      | || |     | |      | || |   |  _|  _   | |
| |  _| |  \ \_  | || |  \  `--'  /  | || |   \ `--' /   | || |   _| |__/ |  | || |  _| |___/ |  | || |    _| |_     | || |    _| |_     | || |  _| |___/ |  | |
| | |____| |___| | || |   `.____.'   | || |    `.__.'    | || |  |________|  | || | |_________|  | || |   |_____|    | || |   |_____|    | || | |_________|  | |
| |              | || |              | || |              | || |              | || |              | || |              | || |              | || |              | |
| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |
 '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'
";
            WriteLine(title);
            Write("Enter your bet :\n");

            Determine.Bet(player);

            //The below is to quantify the result of their bet to visually display it

            WriteLine($"Amount remaining in Wallet : ${player.Cash}\n\n >>Press any key to continue<<");
            ReadKey();
            //The code below is done for cleanliness of UI

            Clear();
            WriteLine($"Wallet : ${player.Cash}      Turn : {player.Turn}\n\n");
            WriteLine("Choose which type of bet you would like to place.");
            Bets.BetMenu(results, player) ;

            //The below code quantifies the winning number sets from the arrays from Results class

            WriteLine($"The Winning Number is :{winNum}");
            if (winColor == "Red")
            {
                Write("The Winning Color is : ");
                BackgroundColor = ConsoleColor.Red;
                Write("Red");
            }
            else if (winColor == "Green")
            {
                Write("The Winning Color is : ");
                BackgroundColor = ConsoleColor.Green;
                Write("Green");
            }
             else { Write("The Winning Color is : "); BackgroundColor = ConsoleColor.White; Write("Black"); }
               
                ReadLine();
                player.Turn++;
        }
    }
}