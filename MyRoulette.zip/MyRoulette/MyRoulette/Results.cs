﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRoulette
{
    class Results
    {
        public Results()
        {
            Random rando = new Random();

            this.Win = false;

            this.CornerWin = false;

            this.WinNum = new int[38]
        {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,0,00 };

          this.WinColor = new string[38]
        {"Red","Black","Red","Black","Red","Black","Red","Black","Red","Black","Black","Red","Black","Red","Black","Red","Black","Red","Red","Black","Red","Black","Red","Black","Red","Black","Red","Black","Black","Red","Black","Red","Black","Red","Black","Red","Green","Green"};
            //Rewrite CornerArray to contain matching corner values for 38 indices ** remember indices begin at 0
            this.CornerArray = new string[22]
          {"1,2,4,5",
            "2,3,5,6",
            "4,5,7,8",
            "5,6,8,9",
            "7,8,10,11",
            "8,9,11,12",
            "10,11,13,14",
            "11,12,14,15",
            "13,14,16,17",
            "14,15,17,18",
            "16,17,19,20",
            "17,18,20,21",
            "19,20,22,23",
            "20,21,23,24",
            "22,23,25,26",
            "23,24,26,27",
            "25,26,28,29",
            "26,27,29,30",
            "28,29,31,32",
            "29,30,32,33",
            "31,32,34,35",
            "32,33,35,36" };
            this.Index = rando.Next(WinNum.Length);
            this.IndexCorner = rando.Next(CornerArray.Length);
         
        }
        public int[] WinNum { get; set; }
        public string[] WinColor { get; set; }
        public string[] CornerArray { get; set; }
        public int Index { get; set; }
        public bool CornerWin { get; set; }
        public int IndexCorner { get; set; }
        public bool Win { get; set; }
    }
}
