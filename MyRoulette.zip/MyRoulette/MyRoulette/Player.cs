﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRoulette
{
    class Player
    {
        public Player()
        {
            this.Play = "";
            this.Cash = 1000;
            this.Turn = 1;
            this.Turns = "";
            this.Bet = "";
            this.Betii = 0;
            this.BetChoice = "";
            this.Running = true;
            this.BetChoiceii = "";
            this.BetChoiceiii = "";
            this.BetChoiceiv = "";
            this.BetOption = "";
            this.Win = false;
            this.ExtraInt = 0;
            this.ExtraIntii = 0;
        }
        public string Play { get; set; }
        public int Cash { get; set; }
        public string Turns { get; set; }
        public int Turn { get; set; }
        public string Bet { get; set; }
        public int Betii { get; set; }
        public string BetChoice { get; set; }
        public string BetChoiceii { get; set; }
        public string BetChoiceiii { get; set; }
        public string BetChoiceiv { get; set; }
        public string BetOption { get; set; }
        public bool Win { get; set; }
        public bool Running { get; set; }
        public int ExtraInt { get; set; }
        public int ExtraIntii { get; set; }
    }
}
