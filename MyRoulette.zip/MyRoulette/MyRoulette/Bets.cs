﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace MyRoulette
{
    class Bets
    {
        public static void BetMenu(Results results, Player player)
        {
            int selection;
            //int betchoice;
            int winNum = results.WinNum[results.Index];
            //Menu for selecting the Bet Type
            WriteLine();
            WriteLine("1: >> Numbers: the number of the bin\n");

            WriteLine("2: >> Evens/Odds: even or odd numbers\n");

            WriteLine("3: >> Reds/Blacks: red or black colored numbers\n");

            WriteLine("4: >> Lows/Highs: low (1 - 18) or high (19 - 38) numbers.\n");

            WriteLine("5: >> Dozens: row thirds, 1 - 12, 13 - 24, 25 - 36\n");

            WriteLine("6: >> Columns: First, second, or third columns\n");

            WriteLine("7: >> Street: rows, e.g., 1/2/3 or 22/23/24\n");

            WriteLine("8: >> 6 Numbers: double rows, e.g., 1/2/3/4/5/6 or 22/23/24/25/26/26\n");

            WriteLine("9: >> Split: at the edge of any two contiguous numbers, e.g., 1/2, 11/14, and 35/36\n");

            WriteLine("10: >> Corner: at the intersection of any four contiguous numbers, e.g., 1/2/4/5, or 23/24/26/27\n");

            WriteLine("11: >> Exit Application");

            string choose = "";
            while (!int.TryParse(choose, out selection))
            {
                choose = ReadLine();
            }
            if (selection > 11 || selection < 1)
            {
                Clear();
                WriteLine(">>INVALID SELECTION<<");
                BetMenu(results, player);
            }
            //The below switch determines the user input and translates the process for the bet type
            switch (selection)
            {
                case 1:
                    Clear();
                    Determine.FindNumber(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 35}!");
                        player.Cash += (player.Betii * 35);
                    }
                    else { WriteLine("You have lost the bet... sorry."); }
                    break;
                case 2:
                    Clear();
                    Determine.EvenOdd(results, player);
                    break;
                case 3:
                    Clear();
                    Determine.Color(results, player);
                    break;
                case 4:
                    Clear();
                    Determine.FindHL(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("Winning Range is : 1 - 18!\n");
                        WriteLine("You've won the bet!");
                        player.Cash += (player.Betii * 2);
                    }
                    else { WriteLine("The Winning Range is : 19-36!\nYou have lost the bet, sorry."); }
                    break;
                case 5:
                    Clear();
                    Determine.FindDozen(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 2}!");
                        player.Cash += (player.Betii * 2);
                    }
                    else { WriteLine("You lost... sorry.."); }
                    break;

                case 6:
                    Clear();
                    Determine.FindColumn(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 17}!");
                        player.Cash += (player.Betii * 17);
                    }
                    else { WriteLine("You lost... sorry.."); }
                    break;

                case 7:
                    Clear();
                    Determine.FindStreet(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 11}!");
                        player.Cash += (player.Betii * 11);
                    }
                    else { WriteLine("You lost... sorry.."); }
                    break;

                case 8:
                    Clear();
                    Determine.FindDub(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 5}!");
                        player.Cash += (player.Betii * 5);
                    }
                    else { WriteLine("You lost... sorry.."); }
                    break;

                case 9:
                    Clear();
                    Determine.FindSplit(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 17}!");
                        player.Cash += (player.Betii * 17);
                    }
                    else { WriteLine("You lost... sorry.."); }
                    break;

                case 10:
                    Clear();
                    Determine.FindCorner(results, player);
                    if (player.Win == true)
                    {
                        WriteLine("You have won the bet! Congratulations!");
                        WriteLine($"You're payout is ${player.Betii * 8}!");
                        player.Cash += (player.Betii * 8);
                    }
                    else { WriteLine("You have lost your bet."); }
                    break;

                case 11:
                    Clear();
                    WriteLine("Thank you for playing!");
                    player.Running = false;
                    Environment.Exit(0);
                    break;
            }
        }
    }
}
