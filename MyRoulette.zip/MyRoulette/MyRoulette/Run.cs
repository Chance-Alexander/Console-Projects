﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace MyRoulette
{
    public class Run
    {
        public static void Start()
        {
            Player player = new Player();
            Results results = new Results();
            GameProcess sp = new GameProcess();
            player.Turn = 1;
            Title = "Chance Alexander's Roulette";

            WriteLine("Welcome to Roulette!\nPlease Maximize the screen to have an optimal experience.");
            ReadLine();

            while (player.Turn <=10)
            {
                GameProcess.Game(player, results);
            }
            Clear();
            Determine.Ask(player, results);
        }
    }
}
