﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyRoulette;
using static System.Console;

namespace Roulette_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            Run run = new Run();
            Run.Start();
        }
    }
}
